# Inselpreis für Android

Native, sehr schlanke Android-App mit eingebetteter Web-Oberfläche.

## Funktionen

- Abflug, Personenzahl, Reisezeitraum und Aufenthaltsdauer festlegen
- griechische Insel auswählen oder mehrere Inseln vergleichen
- Flug, Hotel und Taxi getrennt darstellen
- nur Angebote mit gemeldeter Flug- und Hotelverfügbarkeit anzeigen
- nach Gesamtpreis für alle Reisenden sortieren
- direkte Buchungslinks öffnen
- Demo-Modus ohne Einrichtung
- Live-Modus über einen eigenen HTTPS-JSON-Endpunkt

## Installation

Die Datei `Inselpreis-v1.0.apk` auf das Android-Gerät kopieren und öffnen. Android kann beim ersten Sideload die Freigabe „Unbekannte Apps installieren“ verlangen.

## Sicherheit

Geheime API-Schlüssel gehören nicht in eine APK. Der Live-Modus verwendet deshalb einen selbst betriebenen Backend-Endpunkt. Das erwartete JSON-Format steht in `API_SCHEMA.md`.

## Technische Hinweise

- Paketname: `de.chillionaer.inselpreis`
- Mindestversion: Android 6.0 / API 23
- Zielversion: API 28, damit die APK auch ohne moderne Build-Toolchain breit sideloadbar bleibt
- Signatur: lokale Entwicklungs-/Testsignatur; nicht für eine Veröffentlichung im Play Store gedacht
