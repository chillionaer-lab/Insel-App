// Minimal HTTPS/Node endpoint example for the Inselpreis APK.
// Replace the demo offers with results from your chosen flight/hotel providers.
import http from 'node:http';

const islands = { CFU: 'Korfu', HER: 'Kreta · Heraklion', CHQ: 'Kreta · Chania', KGS: 'Kos', RHO: 'Rhodos', ZTH: 'Zakynthos' };

http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname !== '/api/travel-search') {
    res.writeHead(404).end('Not found');
    return;
  }
  const destination = url.searchParams.get('destination') || 'CFU';
  const iata = destination === 'ALL' ? 'CFU' : destination;
  const adults = Number(url.searchParams.get('adults') || 2);
  const startDate = url.searchParams.get('dateFrom') || '2026-09-22';
  const endDate = '2026-09-29';
  const payload = {
    currency: 'EUR',
    updatedAt: new Date().toISOString(),
    offers: [{
      destination: islands[iata] || iata,
      iata,
      startDate,
      endDate,
      nights: 7,
      flight: { provider: 'API-Anbieter', price: 278, direct: true, available: true, bookingUrl: 'https://www.google.com/travel/flights' },
      hotel: { name: 'Vom Hotelanbieter geliefertes Hotel', room: `Zimmer für ${adults} Personen`, price: 492, available: true, bookingUrl: 'https://www.booking.com/' },
      transfer: { type: 'Taxi hin und zurück', price: 55, available: 'estimate', bookingUrl: 'https://www.google.com/maps' }
    }]
  };
  res.writeHead(200, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Cache-Control': 'no-store'
  });
  res.end(JSON.stringify(payload));
}).listen(8787, () => console.log('http://localhost:8787/api/travel-search'));
