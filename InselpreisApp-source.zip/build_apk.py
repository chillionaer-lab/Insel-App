#!/usr/bin/env python3
"""Build a tiny Android APK without the Android SDK.

The APK contains one Dalvik Activity that opens assets/index.html in a WebView.
It intentionally uses only stable Android framework APIs.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import struct
import subprocess
import tempfile
import zlib
import zipfile
from dataclasses import dataclass
from pathlib import Path

U32_MAX = 0xFFFFFFFF


def uleb128(value: int) -> bytes:
    out = bytearray()
    while True:
        b = value & 0x7F
        value >>= 7
        if value:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)


def align(data: bytearray, n: int) -> None:
    while len(data) % n:
        data.append(0)


def p16(v: int) -> bytes:
    return struct.pack('<H', v)


def p32(v: int) -> bytes:
    return struct.pack('<I', v)


# ---------------- Binary AndroidManifest.xml ----------------
RES_STRING_POOL_TYPE = 0x0001
RES_XML_TYPE = 0x0003
RES_XML_START_NAMESPACE_TYPE = 0x0100
RES_XML_END_NAMESPACE_TYPE = 0x0101
RES_XML_START_ELEMENT_TYPE = 0x0102
RES_XML_END_ELEMENT_TYPE = 0x0103
RES_XML_RESOURCE_MAP_TYPE = 0x0180
TYPE_REFERENCE = 0x01
TYPE_STRING = 0x03
TYPE_INT_DEC = 0x10
TYPE_INT_BOOLEAN = 0x12

ANDROID_URI = 'http://schemas.android.com/apk/res/android'


def enc_len8(n: int) -> bytes:
    if n > 0x7F:
        return bytes([(n >> 8) | 0x80, n & 0xFF])
    return bytes([n])


def utf8_string(s: str) -> bytes:
    raw = s.encode('utf-8')
    # ASCII strings are used here, so Python len is also the UTF-16 length.
    return enc_len8(len(s)) + enc_len8(len(raw)) + raw + b'\x00'


@dataclass
class XmlAttr:
    ns: str | None
    name: str
    raw: str | None
    data_type: int
    data: int | str


class AxmlBuilder:
    def __init__(self) -> None:
        self.strings: list[str] = []
        self.index: dict[str, int] = {}
        self.resource_ids: dict[str, int] = {
            'theme': 0x01010000,
            'label': 0x01010001,
            'name': 0x01010003,
            'exported': 0x01010010,
            'minSdkVersion': 0x0101020C,
            'targetSdkVersion': 0x01010270,
            'versionCode': 0x0101021B,
            'versionName': 0x0101021C,
        }
        self.nodes: list[bytes] = []

    def s(self, value: str) -> int:
        if value not in self.index:
            self.index[value] = len(self.strings)
            self.strings.append(value)
        return self.index[value]

    def node_header(self, chunk_type: int, size: int, line: int = 1) -> bytes:
        return struct.pack('<HHIII', chunk_type, 16, size, line, U32_MAX)

    def namespace(self, start: bool, prefix: str, uri: str) -> None:
        ctype = RES_XML_START_NAMESPACE_TYPE if start else RES_XML_END_NAMESPACE_TYPE
        self.nodes.append(self.node_header(ctype, 24) + p32(self.s(prefix)) + p32(self.s(uri)))

    def start(self, name: str, attrs: list[XmlAttr], ns: str | None = None) -> None:
        ext = bytearray()
        ext += p32(self.s(ns) if ns else U32_MAX)
        ext += p32(self.s(name))
        ext += struct.pack('<HHHHHH', 20, 20, len(attrs), 0, 0, 0)
        for a in attrs:
            ns_idx = self.s(a.ns) if a.ns else U32_MAX
            name_idx = self.s(a.name)
            raw_idx = self.s(a.raw) if a.raw is not None else U32_MAX
            if a.data_type == TYPE_STRING:
                data = self.s(str(a.data))
            else:
                data = int(a.data)
            ext += p32(ns_idx) + p32(name_idx) + p32(raw_idx)
            ext += struct.pack('<HBBI', 8, 0, a.data_type, data)
        size = 16 + len(ext)
        self.nodes.append(self.node_header(RES_XML_START_ELEMENT_TYPE, size) + ext)

    def end(self, name: str, ns: str | None = None) -> None:
        self.nodes.append(self.node_header(RES_XML_END_ELEMENT_TYPE, 24) + p32(self.s(ns) if ns else U32_MAX) + p32(self.s(name)))

    def build_string_pool(self) -> bytes:
        offsets: list[int] = []
        blob = bytearray()
        for s in self.strings:
            offsets.append(len(blob))
            blob += utf8_string(s)
        align(blob, 4)
        header_size = 28
        strings_start = header_size + 4 * len(offsets)
        size = strings_start + len(blob)
        out = bytearray(struct.pack('<HHIIIIII', RES_STRING_POOL_TYPE, header_size, size, len(offsets), 0, 0x100, strings_start, 0))
        for off in offsets:
            out += p32(off)
        out += blob
        return bytes(out)

    def build_resource_map(self) -> bytes:
        ids = [0] * len(self.strings)
        for name, rid in self.resource_ids.items():
            if name in self.index:
                ids[self.index[name]] = rid
        # Android maps resource IDs by string-pool position. Trailing zero entries are harmless.
        size = 8 + 4 * len(ids)
        return struct.pack('<HHI', RES_XML_RESOURCE_MAP_TYPE, 8, size) + b''.join(p32(x) for x in ids)

    def finish(self) -> bytes:
        body = self.build_string_pool() + self.build_resource_map() + b''.join(self.nodes)
        return struct.pack('<HHI', RES_XML_TYPE, 8, 8 + len(body)) + body


def build_manifest() -> bytes:
    b = AxmlBuilder()
    b.namespace(True, 'android', ANDROID_URI)
    b.start('manifest', [
        XmlAttr(None, 'package', 'de.chillionaer.inselpreis', TYPE_STRING, 'de.chillionaer.inselpreis'),
        XmlAttr(ANDROID_URI, 'versionCode', None, TYPE_INT_DEC, 1),
        XmlAttr(ANDROID_URI, 'versionName', '1.0', TYPE_STRING, '1.0'),
    ])
    b.start('uses-sdk', [
        XmlAttr(ANDROID_URI, 'minSdkVersion', None, TYPE_INT_DEC, 23),
        XmlAttr(ANDROID_URI, 'targetSdkVersion', None, TYPE_INT_DEC, 28),
    ])
    b.end('uses-sdk')
    b.start('uses-permission', [XmlAttr(ANDROID_URI, 'name', 'android.permission.INTERNET', TYPE_STRING, 'android.permission.INTERNET')])
    b.end('uses-permission')
    b.start('application', [
        XmlAttr(ANDROID_URI, 'label', 'Inselpreis', TYPE_STRING, 'Inselpreis'),
        XmlAttr(ANDROID_URI, 'theme', None, TYPE_REFERENCE, 0x01030241),
    ])
    b.start('activity', [
        XmlAttr(ANDROID_URI, 'name', 'de.chillionaer.inselpreis.MainActivity', TYPE_STRING, 'de.chillionaer.inselpreis.MainActivity'),
        XmlAttr(ANDROID_URI, 'exported', None, TYPE_INT_BOOLEAN, 0xFFFFFFFF),
        XmlAttr(ANDROID_URI, 'label', 'Inselpreis', TYPE_STRING, 'Inselpreis'),
    ])
    b.start('intent-filter', [])
    b.start('action', [XmlAttr(ANDROID_URI, 'name', 'android.intent.action.MAIN', TYPE_STRING, 'android.intent.action.MAIN')])
    b.end('action')
    b.start('category', [XmlAttr(ANDROID_URI, 'name', 'android.intent.category.LAUNCHER', TYPE_STRING, 'android.intent.category.LAUNCHER')])
    b.end('category')
    b.end('intent-filter')
    b.end('activity')
    b.end('application')
    b.end('manifest')
    b.namespace(False, 'android', ANDROID_URI)
    return b.finish()


# ---------------- classes.dex ----------------
@dataclass(frozen=True)
class Proto:
    return_type: str
    params: tuple[str, ...]


@dataclass(frozen=True)
class Method:
    owner: str
    name: str
    proto: Proto


def shorty(proto: Proto) -> str:
    def ch(t: str) -> str:
        return t if len(t) == 1 else 'L'
    return ch(proto.return_type) + ''.join(ch(t) for t in proto.params)


def invoke35c(opcode: int, method_idx: int, regs: list[int]) -> list[int]:
    if len(regs) > 5 or any(r > 15 for r in regs):
        raise ValueError('35c register overflow')
    padded = regs + [0] * (5 - len(regs))
    c, d, e, f, g = padded
    return [opcode | (g << 8) | (len(regs) << 12), method_idx, c | (d << 4) | (e << 8) | (f << 12)]


def code_item(registers: int, ins: int, outs: int, units: list[int]) -> bytes:
    return struct.pack('<HHHHII', registers, ins, outs, 0, 0, len(units)) + b''.join(p16(x) for x in units)


def build_dex() -> bytes:
    MAIN = 'Lde/chillionaer/inselpreis/MainActivity;'
    ACT = 'Landroid/app/Activity;'
    BUNDLE = 'Landroid/os/Bundle;'
    WEBVIEW = 'Landroid/webkit/WebView;'
    WEBSETTINGS = 'Landroid/webkit/WebSettings;'
    STRING = 'Ljava/lang/String;'
    VIEW = 'Landroid/view/View;'
    CONTEXT = 'Landroid/content/Context;'
    V = 'V'
    Z = 'Z'

    p_void = Proto(V, ())
    p_bundle = Proto(V, (BUNDLE,))
    p_view = Proto(V, (VIEW,))
    p_context = Proto(V, (CONTEXT,))
    p_get_settings = Proto(WEBSETTINGS, ())
    p_bool = Proto(V, (Z,))
    p_string = Proto(V, (STRING,))

    methods = [
        Method(ACT, '<init>', p_void),
        Method(ACT, 'onCreate', p_bundle),
        Method(ACT, 'setContentView', p_view),
        Method(WEBVIEW, '<init>', p_context),
        Method(WEBVIEW, 'getSettings', p_get_settings),
        Method(WEBVIEW, 'loadUrl', p_string),
        Method(WEBSETTINGS, 'setJavaScriptEnabled', p_bool),
        Method(WEBSETTINGS, 'setDomStorageEnabled', p_bool),
        Method(WEBSETTINGS, 'setAllowUniversalAccessFromFileURLs', p_bool),
        Method(MAIN, '<init>', p_void),
        Method(MAIN, 'onCreate', p_bundle),
    ]

    extra_strings = ['MainActivity.java', 'file:///android_asset/index.html']
    all_strings = set(extra_strings)
    for t in [MAIN, ACT, BUNDLE, WEBVIEW, WEBSETTINGS, STRING, VIEW, CONTEXT, V, Z]:
        all_strings.add(t)
    for m in methods:
        all_strings.add(m.name)
        all_strings.add(shorty(m.proto))
    strings = sorted(all_strings)
    sidx = {s: i for i, s in enumerate(strings)}

    types = sorted([MAIN, ACT, BUNDLE, WEBVIEW, WEBSETTINGS, STRING, VIEW, CONTEXT, V, Z], key=lambda t: sidx[t])
    tidx = {t: i for i, t in enumerate(types)}

    protos = sorted({m.proto for m in methods}, key=lambda p: (tidx[p.return_type], tuple(tidx[x] for x in p.params)))
    pidx = {p: i for i, p in enumerate(protos)}

    methods_sorted = sorted(methods, key=lambda m: (tidx[m.owner], sidx[m.name], pidx[m.proto]))
    midx = {m: i for i, m in enumerate(methods_sorted)}

    # Fixed tables start directly after the header.
    header_size = 0x70
    string_ids_off = header_size
    type_ids_off = string_ids_off + 4 * len(strings)
    proto_ids_off = type_ids_off + 4 * len(types)
    method_ids_off = proto_ids_off + 12 * len(protos)
    class_defs_off = method_ids_off + 8 * len(methods_sorted)
    data_off = class_defs_off + 32

    data = bytearray()

    # String data items.
    string_data_offs: list[int] = []
    for s in strings:
        off = data_off + len(data)
        string_data_offs.append(off)
        encoded = s.encode('utf-8')
        data += uleb128(len(s)) + encoded + b'\x00'

    # Type lists used by prototype parameter lists.
    proto_param_off: dict[tuple[str, ...], int] = {(): 0}
    for params in sorted({p.params for p in protos if p.params}, key=lambda x: tuple(tidx[t] for t in x)):
        align(data, 4)
        proto_param_off[params] = data_off + len(data)
        data += p32(len(params))
        for t in params:
            data += p16(tidx[t])
        align(data, 4)

    # Code items.
    align(data, 4)
    init_code_off = data_off + len(data)
    init_units = []
    init_units += invoke35c(0x70, midx[Method(ACT, '<init>', p_void)], [0])
    init_units += [0x000E]
    data += code_item(1, 1, 1, init_units)

    align(data, 4)
    oncreate_code_off = data_off + len(data)
    # v0 WebView, v1 WebSettings/String, v2 boolean, v3 p0, v4 p1
    units: list[int] = []
    units += invoke35c(0x6F, midx[Method(ACT, 'onCreate', p_bundle)], [3, 4])
    units += [0x0022, tidx[WEBVIEW]]  # new-instance v0
    units += invoke35c(0x70, midx[Method(WEBVIEW, '<init>', p_context)], [0, 3])
    units += invoke35c(0x6E, midx[Method(WEBVIEW, 'getSettings', p_get_settings)], [0])
    units += [0x010C]  # move-result-object v1
    units += [0x1212]  # const/4 v2, #1
    units += invoke35c(0x6E, midx[Method(WEBSETTINGS, 'setJavaScriptEnabled', p_bool)], [1, 2])
    units += invoke35c(0x6E, midx[Method(WEBSETTINGS, 'setDomStorageEnabled', p_bool)], [1, 2])
    units += invoke35c(0x6E, midx[Method(WEBSETTINGS, 'setAllowUniversalAccessFromFileURLs', p_bool)], [1, 2])
    units += [0x011A, sidx['file:///android_asset/index.html']]  # const-string v1
    units += invoke35c(0x6E, midx[Method(WEBVIEW, 'loadUrl', p_string)], [0, 1])
    units += invoke35c(0x6E, midx[Method(ACT, 'setContentView', p_view)], [3, 0])
    units += [0x000E]
    data += code_item(5, 2, 2, units)

    # Class data item (ULEB128, no alignment requirement).
    class_data_off = data_off + len(data)
    main_init_idx = midx[Method(MAIN, '<init>', p_void)]
    main_oncreate_idx = midx[Method(MAIN, 'onCreate', p_bundle)]
    class_data = bytearray()
    class_data += uleb128(0) + uleb128(0) + uleb128(1) + uleb128(1)
    class_data += uleb128(main_init_idx) + uleb128(0x10001) + uleb128(init_code_off)
    class_data += uleb128(main_oncreate_idx) + uleb128(0x0004) + uleb128(oncreate_code_off)
    data += class_data

    # Map list.
    align(data, 4)
    map_off = data_off + len(data)
    map_entries = [
        (0x0000, 1, 0),
        (0x0001, len(strings), string_ids_off),
        (0x0002, len(types), type_ids_off),
        (0x0003, len(protos), proto_ids_off),
        (0x0005, len(methods_sorted), method_ids_off),
        (0x0006, 1, class_defs_off),
        (0x2002, len(strings), min(string_data_offs)),
    ]
    nonempty_param_lists = [x for x in proto_param_off.values() if x]
    if nonempty_param_lists:
        map_entries.append((0x1001, len(nonempty_param_lists), min(nonempty_param_lists)))
    map_entries += [
        (0x2001, 2, init_code_off),
        (0x2000, 1, class_data_off),
        (0x1000, 1, map_off),
    ]
    map_entries.sort(key=lambda x: x[2])
    data += p32(len(map_entries))
    for typ, count, off in map_entries:
        data += struct.pack('<HHII', typ, 0, count, off)

    # Fixed tables.
    fixed = bytearray()
    for off in string_data_offs:
        fixed += p32(off)
    for t in types:
        fixed += p32(sidx[t])
    for proto in protos:
        fixed += p32(sidx[shorty(proto)]) + p32(tidx[proto.return_type]) + p32(proto_param_off[proto.params])
    for m in methods_sorted:
        fixed += struct.pack('<HHI', tidx[m.owner], pidx[m.proto], sidx[m.name])
    fixed += struct.pack('<IIIIIIII',
        tidx[MAIN], 0x0001, tidx[ACT], 0, sidx['MainActivity.java'], 0, class_data_off, 0
    )

    if len(fixed) != data_off - header_size:
        raise AssertionError((len(fixed), data_off - header_size))

    file_size = data_off + len(data)
    header = bytearray(0x70)
    header[0:8] = b'dex\n035\x00'
    # checksum and SHA-1 are filled after assembling.
    struct.pack_into('<20I', header, 32,
        file_size, header_size, 0x12345678, 0, 0, map_off,
        len(strings), string_ids_off,
        len(types), type_ids_off,
        len(protos), proto_ids_off,
        0, 0,
        len(methods_sorted), method_ids_off,
        1, class_defs_off,
        len(data), data_off,
    )
    dex = bytearray(header + fixed + data)
    dex[12:32] = hashlib.sha1(dex[32:]).digest()
    struct.pack_into('<I', dex, 8, zlib.adler32(dex[12:]) & 0xFFFFFFFF)
    return bytes(dex)


def make_unsigned(apk_path: Path, html_path: Path) -> None:
    manifest = build_manifest()
    dex = build_dex()
    with zipfile.ZipFile(apk_path, 'w') as z:
        z.writestr('AndroidManifest.xml', manifest, compress_type=zipfile.ZIP_DEFLATED)
        z.writestr('classes.dex', dex, compress_type=zipfile.ZIP_DEFLATED)
        z.write(html_path, 'assets/index.html', compress_type=zipfile.ZIP_DEFLATED)


def sign_apk(unsigned: Path, signed: Path, keystore: Path) -> None:
    if not keystore.exists():
        subprocess.run([
            'keytool', '-genkeypair', '-v', '-keystore', str(keystore), '-storepass', 'inselpreis',
            '-keypass', 'inselpreis', '-alias', 'inselpreis', '-keyalg', 'RSA', '-keysize', '2048',
            '-validity', '10000', '-dname', 'CN=Inselpreis Development,O=Local Build,C=DE'
        ], check=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    shutil.copy2(unsigned, signed)
    subprocess.run([
        'jarsigner', '-keystore', str(keystore), '-storepass', 'inselpreis', '-keypass', 'inselpreis',
        '-sigalg', 'SHA256withRSA', '-digestalg', 'SHA-256', str(signed), 'inselpreis'
    ], check=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', default='Inselpreis-v1.0.apk')
    args = ap.parse_args()
    root = Path(__file__).resolve().parent
    output = root / args.output
    unsigned = root / 'Inselpreis-unsigned.apk'
    keystore = root / 'inselpreis-dev.keystore'
    make_unsigned(unsigned, root / 'assets' / 'index.html')
    sign_apk(unsigned, output, keystore)
    print(output)


if __name__ == '__main__':
    main()
