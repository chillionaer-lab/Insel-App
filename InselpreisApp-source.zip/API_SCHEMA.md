# Inselpreis Live-API

Die APK speichert keine geheimen Anbieter-Schlüssel. Stattdessen ruft sie einen eigenen HTTPS-Endpunkt mit folgenden GET-Parametern auf:

`origin`, `adults`, `dateFrom`, `dateTo`, `minNights`, `maxNights`, `destination`

Beispiel:

```text
https://example.com/api/travel-search?origin=BER&adults=2&dateFrom=2026-08-01&dateTo=2026-09-30&minNights=4&maxNights=7&destination=ALL
```

Erwartete Antwort:

```json
{
  "currency": "EUR",
  "updatedAt": "2026-07-12T14:00:00+02:00",
  "offers": [
    {
      "destination": "Korfu",
      "iata": "CFU",
      "startDate": "2026-09-22",
      "endDate": "2026-09-29",
      "nights": 7,
      "flight": {
        "provider": "easyJet",
        "price": 278.00,
        "direct": true,
        "available": true,
        "bookingUrl": "https://..."
      },
      "hotel": {
        "name": "Beispielhotel",
        "room": "Doppelzimmer",
        "price": 492.00,
        "available": true,
        "bookingUrl": "https://..."
      },
      "transfer": {
        "type": "Taxi hin und zurück",
        "price": 55.00,
        "available": "estimate",
        "bookingUrl": "https://..."
      }
    }
  ]
}
```

Die App berechnet den Gesamtpreis selbst und entfernt Angebote, bei denen `flight.available` oder `hotel.available` den Wert `false` hat.
